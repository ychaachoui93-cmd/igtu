Attribute VB_Name = "modDashboard"
Option Explicit

Public Sub ActualiserDashboard()
    Dim wsHistorique As Worksheet
    Dim wsDashboard As Worksheet
    Dim derniereLigne As Long
    Dim ligneDestination As Long
    Dim dictionnaire As Object
    Dim persoID As String
    Dim dateCourante As Date
    Dim datePrecedente As Date
    Dim etatEvenements As Boolean

    On Error GoTo GestionErreur

    Application.ScreenUpdating = False
    etatEvenements = Application.EnableEvents
    Application.EnableEvents = False
    AssurerStructureClasseur

    Set wsHistorique = ThisWorkbook.Worksheets(FEUILLE_HISTORIQUE)
    Set wsDashboard = ThisWorkbook.Worksheets(FEUILLE_DASHBOARD)
    persoID = VBA.Environ$("USERNAME")

    derniereLigne = wsHistorique.Cells(wsHistorique.Rows.Count, "A").End(xlUp).Row
    If derniereLigne >= 2 Then wsHistorique.Range("A2:N" & derniereLigne).ClearContents

    Set dictionnaire = CreateObject("Scripting.Dictionary")
    dictionnaire.CompareMode = vbTextCompare
    ligneDestination = 2

    dateCourante = DateSerial(Year(Date), Month(Date), 1)
    datePrecedente = DateAdd("m", -1, dateCourante)

    ImporterCSVVersHistorique CheminFichierCSV(persoID, datePrecedente), _
        wsHistorique, ligneDestination, dictionnaire
    ImporterCSVVersHistorique CheminFichierCSV(persoID, dateCourante), _
        wsHistorique, ligneDestination, dictionnaire

    wsDashboard.Range("B3").Value = persoID
    wsDashboard.Range("E3").Value = Now
    wsDashboard.Range("E3").NumberFormat = "dd/mm/yyyy hh:mm:ss"

    If Not IsDate(wsDashboard.Range("B10").Value) Then
        wsDashboard.Range("B10").Value = Date
    ElseIf Month(CDate(wsDashboard.Range("B10").Value)) <> Month(Date) Or _
           Year(CDate(wsDashboard.Range("B10").Value)) <> Year(Date) Then
        wsDashboard.Range("B10").Value = Date
    End If

    Application.CalculateFull
    RafraichirDetailDashboard CDate(wsDashboard.Range("B10").Value)

Sortie:
    Application.EnableEvents = etatEvenements
    Application.ScreenUpdating = True
    Exit Sub

GestionErreur:
    MsgBox "Le dashboard n'a pas pu etre actualise." & vbCrLf & vbCrLf & _
        Err.Number & " - " & Err.Description, vbExclamation, "Dashboard"
    Resume Sortie
End Sub

Public Sub RafraichirDetailDashboard(Optional ByVal dateSelectionnee As Variant)
    Dim wsDashboard As Worksheet
    Dim wsHistorique As Worksheet
    Dim wsTemp As Worksheet
    Dim persoID As String
    Dim dateDetail As Date
    Dim ligneDestination As Long
    Dim derniereLigne As Long
    Dim i As Long
    Dim etatEvenements As Boolean

    On Error GoTo GestionErreur
    etatEvenements = Application.EnableEvents
    Application.EnableEvents = False

    Set wsDashboard = ThisWorkbook.Worksheets(FEUILLE_DASHBOARD)
    Set wsHistorique = ThisWorkbook.Worksheets(FEUILLE_HISTORIQUE)
    Set wsTemp = ThisWorkbook.Worksheets(FEUILLE_TEMP)
    persoID = VBA.Environ$("USERNAME")

    If IsMissing(dateSelectionnee) Then
        dateDetail = Date
    ElseIf Not IsDate(dateSelectionnee) Then
        dateDetail = Date
    Else
        dateDetail = DateValue(CDate(dateSelectionnee))
    End If

    If Month(dateDetail) <> Month(Date) Or Year(dateDetail) <> Year(Date) Then
        MsgBox "Selectionnez un jour du mois en cours.", vbExclamation, "Date du detail"
        dateDetail = Date
    End If

    wsDashboard.Range("B10").Value = dateDetail
    wsDashboard.Range("B10").NumberFormat = "dd/mm/yyyy"
    wsDashboard.Range("A53:I5000").ClearContents
    wsDashboard.Range("A50").Value = "Detail du " & Format$(dateDetail, "dd/mm/yyyy")
    ligneDestination = 53

    derniereLigne = wsHistorique.Cells(wsHistorique.Rows.Count, "A").End(xlUp).Row
    For i = 2 To derniereLigne
        If UCase$(Trim$(CStr(wsHistorique.Cells(i, "B").Value))) = UCase$(persoID) And _
           IsDate(wsHistorique.Cells(i, "J").Value) Then
            If DateValue(wsHistorique.Cells(i, "J").Value) = dateDetail Then
                EcrireDetail wsDashboard, ligneDestination, "ENREGISTREE", _
                    wsHistorique.Cells(i, "A").Value, wsHistorique.Cells(i, "C").Value, _
                    wsHistorique.Cells(i, "D").Value, wsHistorique.Cells(i, "E").Value, _
                    wsHistorique.Cells(i, "F").Value, wsHistorique.Cells(i, "G").Value, _
                    wsHistorique.Cells(i, "H").Value, wsHistorique.Cells(i, "I").Value
                ligneDestination = ligneDestination + 1
            End If
        End If
    Next i

    derniereLigne = wsTemp.Cells(wsTemp.Rows.Count, "A").End(xlUp).Row
    For i = 2 To derniereLigne
        If UCase$(Trim$(CStr(wsTemp.Cells(i, "C").Value))) = UCase$(persoID) And _
           UCase$(Trim$(CStr(wsTemp.Cells(i, "K").Value))) = ETAT_A_ENREGISTRER And _
           IsDate(wsTemp.Cells(i, "M").Value) Then
            If DateValue(wsTemp.Cells(i, "M").Value) = dateDetail Then
                EcrireDetail wsDashboard, ligneDestination, "EN ATTENTE", _
                    wsTemp.Cells(i, "B").Value, wsTemp.Cells(i, "D").Value, _
                    wsTemp.Cells(i, "E").Value, wsTemp.Cells(i, "F").Value, _
                    wsTemp.Cells(i, "G").Value, wsTemp.Cells(i, "H").Value, _
                    wsTemp.Cells(i, "I").Value, wsTemp.Cells(i, "J").Value
                ligneDestination = ligneDestination + 1
            End If
        End If
    Next i

    If ligneDestination = 53 Then
        wsDashboard.Range("A53").Value = "Aucune realisation pour cette date."
    Else
        wsDashboard.Range("C53:C" & ligneDestination - 1).NumberFormat = "dd/mm/yyyy hh:mm:ss"
    End If

Sortie:
    Application.EnableEvents = etatEvenements
    Exit Sub

GestionErreur:
    MsgBox "Impossible d'afficher le detail : " & Err.Description, vbExclamation, "Dashboard"
    Resume Sortie
End Sub

Private Sub EcrireDetail(ByVal ws As Worksheet, ByVal ligne As Long, ByVal etat As String, _
        ByVal numeroDossier As Variant, ByVal dateHeure As Variant, ByVal activite As Variant, _
        ByVal produit As Variant, ByVal typeDossier As Variant, ByVal decision As Variant, _
        ByVal dispo As Variant, ByVal commentaire As Variant)

    ws.Cells(ligne, "A").Value = etat
    ws.Cells(ligne, "B").Value = numeroDossier
    ws.Cells(ligne, "C").Value = dateHeure
    ws.Cells(ligne, "D").Value = activite
    ws.Cells(ligne, "E").Value = produit
    ws.Cells(ligne, "F").Value = typeDossier
    ws.Cells(ligne, "G").Value = decision
    ws.Cells(ligne, "H").Value = dispo
    ws.Cells(ligne, "I").Value = commentaire
End Sub

Public Sub AfficherDashboard()
    ActualiserDashboard
    ThisWorkbook.Worksheets(FEUILLE_DASHBOARD).Visible = xlSheetVisible
    ThisWorkbook.Worksheets(FEUILLE_DASHBOARD).Activate
End Sub
