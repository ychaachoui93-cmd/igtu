KIT USERFORM + CSV + DASHBOARD — EXCEL LTSC 2021
==================================================

INSTALLATION AUTOMATIQUE DU USERFORM
------------------------------------

1. Ouvrez Modele_UserForm_Dashboard_Excel2021.xlsx.
2. Enregistrez-le immédiatement au format Classeur Excel prenant en charge les
   macros (*.xlsm), dans le même dossier que les fichiers du kit.
3. Dans Excel, activez l'autorisation suivante :
   Fichier > Options > Centre de gestion de la confidentialité > Paramètres du
   Centre de gestion de la confidentialité > Paramètres des macros >
   « Accès approuvé au modèle d'objet du projet VBA ».
   Fermez puis rouvrez Excel si vous venez de modifier ce réglage.
4. Ouvrez l'éditeur VBA avec Alt+F11.
5. Importez les cinq modules via Fichier > Importer un fichier :
   - modInstallerUserForm.bas
   - modConfiguration.bas
   - modCSV.bas
   - modDashboard.bas
   - modFormulaire.bas
6. Vérifiez que UserForm1_Code.txt se trouve à côté du classeur .xlsm. Si ce
   n'est pas le cas, l'installateur vous permettra de le sélectionner.
7. Revenez dans Excel, appuyez sur Alt+F8 et lancez
   InstallerUserFormComplet.
8. Collez ThisWorkbook_Code.txt dans l'objet ThisWorkbook.
9. Collez Dashboard_Code.txt dans le module de la feuille Dashboard.
10. Dans le menu Débogage, lancez Compiler VBAProject.
11. Enregistrez, fermez, rouvrez le classeur et activez les macros.

Si UserForm1 existe déjà, l'installateur propose son remplacement et exporte
d'abord une sauvegarde horodatée Sauvegarde_UserForm1_*.frm dans le dossier du
classeur. Aucun placement manuel ni renommage de contrôle n'est nécessaire.

ORGANISATION DU USERFORM
------------------------

- Bandeau supérieur : titre et rappel du flux temporaire / CSV / suivi.
- Colonne gauche : contexte agent puis tous les champs de saisie dans l'ordre
  naturel de tabulation.
- Zone principale droite : file d'attente mise à jour immédiatement après
  chaque ajout. Un clic sur une ligne affiche son commentaire complet dans la
  zone d'état.
- Bas droit : synthèse agent (en attente, jour, semaine, mois) et boutons
  d'action regroupés.
- Boutons différenciés visuellement : Ajouter, Supprimer, Enregistrer,
  Dashboard et Fermer.
- Formulaire non modal : l'agent peut consulter Excel et le dashboard sans
  perdre sa saisie.

CONTRÔLES CRÉÉS AUTOMATIQUEMENT
------------------------------

- TextBox : txtNumeroDossier, txtPersoID, txtDateTime, txtCommentaire
- ComboBox : cboActivite, cboProduit, cboTypeDossier, cboDecision, cboDispo
- ListBox : ListBox1, ListBox2
- Label d'état : Label1
- Boutons : btnValider, btnSupprimer, btnEnregistrer, btnDashboard, btnFermer

Les listes déroulantes utilisent le style de sélection stricte. Le commentaire
est multiligne, limité à 500 caractères et doté d'une barre de défilement.

RÈGLES APPLIQUÉES
-----------------

- Octroi Classique :
  Produit selon la table des paramètres ; Type de dossier obligatoire ;
  Décision obligatoire ; Dispo obligatoire.
- Live Console :
  Produit selon la table ; Type de dossier et Dispo désactivés et exportés vides ;
  Décision obligatoire.
- Live CLA :
  Produit CLA ; Type de dossier et Dispo désactivés et exportés vides ;
  Décision obligatoire.
- Le commentaire et le numéro de dossier restent obligatoires.

FONCTIONNEMENT DES BOUTONS
--------------------------

- Ajouter :
  valide les champs, bloque les doublons de la session et écrit seulement dans
  DATA_Temp. Le CSV n'est pas modifié.
- Supprimer :
  retire uniquement la ligne sélectionnée de DATA_Temp.
- Enregistrer :
  charge le CSV une seule fois par mois, construit un index de doublons, ignore
  les doublons, réécrit le fichier de façon sécurisée, puis retire de DATA_Temp
  les lignes traitées.
- Dashboard :
  actualise les indicateurs et ouvre la feuille Dashboard.
- Fermer :
  avertit s'il reste des lignes en attente. Ces lignes restent dans DATA_Temp.

CSV ET COMPATIBILITÉ
--------------------

- Dossier conservé :
  \\Uf11pu01\EIDS_FLOA_OCTROI\BO Avenant_Courrier\DATA_Source\CSV\AAAA_MM\
- Fichier : <PersoID>.csv
- Séparateur : point-virgule.
- Encodage produit : UTF-8.
- Les commentaires contenant des points-virgules ou des guillemets sont gérés.
- L'ancien CSV à 7 colonnes est migré à 9 colonnes lors du premier
  enregistrement. L'écriture atomique utilise temporairement un fichier .bak.

DASHBOARD
---------

- Les indicateurs affichent les volumes enregistrés du jour, de la semaine et
  du mois, ainsi que le nombre de lignes en attente.
- Le tableau et le graphique présentent les jours du mois courant.
- La cellule Dashboard!B10 permet de choisir un jour du mois courant ; le détail
  enregistré et en attente s'affiche à partir de la ligne 53.
- Le dashboard charge le fichier du mois courant et celui du mois précédent afin
  de couvrir une semaine qui chevauche deux mois.

PARAMÈTRES
----------

Le chemin de base est en Parametres!Q2. Les choix du formulaire proviennent des
tables tblActivites, tblProduits, tblTypesDossier, tblDecisions et tblDispo.
Vous pouvez donc modifier les listes sans changer le code VBA.

DÉPANNAGE
---------

- Erreur 438 pendant l'installation : utilisez modInstallerUserForm.bas version
  1.1 ou supérieure. Cette version n'écrit plus la propriété de conception
  ShowModal, qui n'est pas exposée de la même façon par toutes les installations
  de MSForms. Le mode non modal reste appliqué lors de l'ouverture du formulaire.
- Message « Excel bloque l'accès au projet VBA » : activez l'option décrite à
  l'étape 3, fermez complètement Excel puis réessayez.
- Le formulaire ne s'ouvre pas : vérifiez que UserForm1 existe dans le projet,
  puis lancez Débogage > Compiler VBAProject.
- Le CSV n'est pas accessible : contrôlez le chemin Parametres!Q2 et les droits
  d'écriture sur le dossier réseau.
