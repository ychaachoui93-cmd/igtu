Attribute VB_Name = "modFormulaire"
Option Explicit

Public Sub OuvrirFormulaireSaisie()
    On Error GoTo GestionErreur

    AssurerStructureClasseur

    If MonFormulaireSaisie Is Nothing Then
        Set MonFormulaireSaisie = VBA.UserForms.Add("UserForm1")
    End If

    MonFormulaireSaisie.Show vbModeless
    ProgrammerReinitialisationMinuit
    Exit Sub

GestionErreur:
    Set MonFormulaireSaisie = Nothing
    MsgBox "Impossible d'ouvrir le formulaire : " & Err.Description, vbCritical, "Formulaire"
End Sub

Public Sub FermerFormulaireSaisie()
    On Error Resume Next
    AnnulerReinitialisationMinuit
    If Not MonFormulaireSaisie Is Nothing Then Unload MonFormulaireSaisie
    Set MonFormulaireSaisie = Nothing
    On Error GoTo 0
End Sub

Public Sub ProgrammerReinitialisationMinuit()
    On Error Resume Next
    AnnulerReinitialisationMinuit
    On Error GoTo 0

    ProchaineReinitialisation = DateAdd("d", 1, Date) + TimeSerial(0, 0, 1)
    Application.OnTime EarliestTime:=ProchaineReinitialisation, _
        Procedure:="ReinitialiserPourNouveauJour", Schedule:=True
End Sub

Public Sub AnnulerReinitialisationMinuit()
    If ProchaineReinitialisation = 0 Then Exit Sub

    On Error Resume Next
    Application.OnTime EarliestTime:=ProchaineReinitialisation, _
        Procedure:="ReinitialiserPourNouveauJour", Schedule:=False
    On Error GoTo 0
    ProchaineReinitialisation = 0
End Sub

Public Sub ReinitialiserPourNouveauJour()
    On Error Resume Next
    ActualiserDashboard
    If Not MonFormulaireSaisie Is Nothing Then MonFormulaireSaisie.NouveauJour
    ProgrammerReinitialisationMinuit
    On Error GoTo 0
End Sub
