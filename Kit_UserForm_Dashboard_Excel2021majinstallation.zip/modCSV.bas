Attribute VB_Name = "modCSV"
Option Explicit

Private Const adTypeBinary As Long = 1
Private Const adTypeText As Long = 2
Private Const adReadAll As Long = -1
Private Const adSaveCreateOverWrite As Long = 2

Public Function EnregistrerSaisiesEnAttente(ByRef nbAjoutees As Long, _
        ByRef nbDoublons As Long) As Boolean

    Dim ws As Worksheet
    Dim derniereLigne As Long
    Dim groupes As Object
    Dim lignesMois As Collection
    Dim lignesReussies As Object
    Dim cleMois As Variant
    Dim persoID As String
    Dim i As Long
    Dim dateSaisie As Date
    Dim ajouteesMois As Long
    Dim doublonsMois As Long

    On Error GoTo GestionErreur

    AssurerStructureClasseur
    Set ws = ThisWorkbook.Worksheets(FEUILLE_TEMP)
    derniereLigne = ws.Cells(ws.Rows.Count, "A").End(xlUp).Row
    persoID = VBA.Environ$("USERNAME")

    Set groupes = CreateObject("Scripting.Dictionary")
    groupes.CompareMode = vbTextCompare
    Set lignesReussies = CreateObject("Scripting.Dictionary")
    lignesReussies.CompareMode = vbTextCompare

    For i = 2 To derniereLigne
        If UCase$(Trim$(CStr(ws.Cells(i, "K").Value))) = ETAT_A_ENREGISTRER And _
           UCase$(Trim$(CStr(ws.Cells(i, "C").Value))) = UCase$(persoID) Then

            If Not IsDate(ws.Cells(i, "D").Value) Then
                Err.Raise vbObjectError + 2200, "EnregistrerSaisiesEnAttente", _
                    "Date temporaire invalide a la ligne " & i & "."
            End If

            dateSaisie = CDate(ws.Cells(i, "D").Value)
            cleMois = Format$(dateSaisie, "yyyy_mm")

            If Not groupes.Exists(cleMois) Then
                Set lignesMois = New Collection
                groupes.Add cleMois, lignesMois
            End If

            Set lignesMois = groupes(cleMois)
            lignesMois.Add i
        End If
    Next i

    If groupes.Count = 0 Then
        EnregistrerSaisiesEnAttente = True
        Exit Function
    End If

    Application.ScreenUpdating = False

    For Each cleMois In groupes.Keys
        Set lignesMois = groupes(cleMois)
        ajouteesMois = 0
        doublonsMois = 0

        EnregistrerGroupeMois ws, lignesMois, persoID, CStr(cleMois), _
            lignesReussies, ajouteesMois, doublonsMois

        nbAjoutees = nbAjoutees + ajouteesMois
        nbDoublons = nbDoublons + doublonsMois
    Next cleMois

    For i = derniereLigne To 2 Step -1
        If lignesReussies.Exists(CStr(ws.Cells(i, "A").Value)) Then ws.Rows(i).Delete
    Next i

    SauvegarderClasseurSiPossible
    EnregistrerSaisiesEnAttente = True

Sortie:
    Application.ScreenUpdating = True
    Exit Function

GestionErreur:
    EnregistrerSaisiesEnAttente = False
    MsgBox "Enregistrement CSV interrompu." & vbCrLf & vbCrLf & _
        Err.Number & " - " & Err.Description, vbCritical, "Erreur CSV"
    Resume Sortie
End Function

Private Sub EnregistrerGroupeMois(ByVal ws As Worksheet, ByVal lignesMois As Collection, _
        ByVal persoID As String, ByVal cleMois As String, ByVal lignesReussies As Object, _
        ByRef nbAjoutees As Long, ByRef nbDoublons As Long)

    Dim dateReference As Date
    Dim cheminDossier As String
    Dim cheminFichier As String
    Dim contenuExistant As String
    Dim contenuFinal As String
    Dim dictionnaire As Object
    Dim lignesExistantes As Collection
    Dim champs As Variant
    Dim ligneIndex As Variant
    Dim cle As String
    Dim ligneCSV As Variant
    Dim idTemp As String

    dateReference = DateSerial(CLng(Left$(cleMois, 4)), CLng(Right$(cleMois, 2)), 1)
    cheminDossier = CheminCSVPourDate(dateReference)
    cheminFichier = CheminFichierCSV(persoID, dateReference)

    AssurerDossier CheminBase() & "CSV\"
    AssurerDossier cheminDossier

    Set dictionnaire = CreateObject("Scripting.Dictionary")
    dictionnaire.CompareMode = vbTextCompare
    Set lignesExistantes = New Collection

    If Len(Dir$(cheminFichier, vbNormal)) > 0 Then
        contenuExistant = LireFichierTexte(cheminFichier)
        ChargerLignesExistantes contenuExistant, lignesExistantes, dictionnaire
    End If

    contenuFinal = CSV_HEADER & vbCrLf

    For Each ligneCSV In lignesExistantes
        contenuFinal = contenuFinal & CStr(ligneCSV) & vbCrLf
    Next ligneCSV

    For Each ligneIndex In lignesMois
        champs = Array( _
            CStr(ws.Cells(CLng(ligneIndex), "B").Value), _
            CStr(ws.Cells(CLng(ligneIndex), "C").Value), _
            Format$(CDate(ws.Cells(CLng(ligneIndex), "D").Value), "yyyy-mm-dd hh:nn:ss"), _
            CStr(ws.Cells(CLng(ligneIndex), "E").Value), _
            CStr(ws.Cells(CLng(ligneIndex), "F").Value), _
            CStr(ws.Cells(CLng(ligneIndex), "G").Value), _
            CStr(ws.Cells(CLng(ligneIndex), "H").Value), _
            CStr(ws.Cells(CLng(ligneIndex), "I").Value), _
            CStr(ws.Cells(CLng(ligneIndex), "J").Value))

        cle = ConstruireCleDoublon(champs(0), champs(1), champs(3), champs(4), _
            champs(5), champs(6), champs(7), champs(8))

        idTemp = CStr(ws.Cells(CLng(ligneIndex), "A").Value)

        If dictionnaire.Exists(cle) Then
            nbDoublons = nbDoublons + 1
            lignesReussies(idTemp) = True
        Else
            ligneCSV = ConstruireLigneCSV(champs)
            contenuFinal = contenuFinal & ligneCSV & vbCrLf
            dictionnaire.Add cle, True
            lignesReussies(idTemp) = True
            nbAjoutees = nbAjoutees + 1
        End If
    Next ligneIndex

    EcrireFichierAtomique cheminFichier, contenuFinal
End Sub

Private Sub ChargerLignesExistantes(ByVal contenu As String, ByVal lignesNormalisees As Collection, _
        ByVal dictionnaire As Object)

    Dim lignes As Variant
    Dim i As Long
    Dim champs As Variant
    Dim champsNormalises As Variant
    Dim cle As String
    Dim ligne As String

    contenu = Replace$(contenu, vbCrLf, vbLf)
    contenu = Replace$(contenu, vbCr, vbLf)
    lignes = Split(contenu, vbLf)

    For i = LBound(lignes) + 1 To UBound(lignes)
        ligne = CStr(lignes(i))
        If Len(Trim$(ligne)) > 0 Then
            champs = AnalyserLigneCSV(ligne)
            champsNormalises = NormaliserAncienOuNouveauFormat(champs)

            cle = ConstruireCleDoublon(champsNormalises(0), champsNormalises(1), _
                champsNormalises(3), champsNormalises(4), champsNormalises(5), _
                champsNormalises(6), champsNormalises(7), champsNormalises(8))

            If Not dictionnaire.Exists(cle) Then
                dictionnaire.Add cle, True
                lignesNormalisees.Add ConstruireLigneCSV(champsNormalises)
            End If
        End If
    Next i
End Sub

Private Function NormaliserAncienOuNouveauFormat(ByVal champs As Variant) As Variant
    Dim resultat(0 To 8) As String
    Dim nombreChamps As Long

    nombreChamps = UBound(champs) - LBound(champs) + 1

    If nombreChamps >= 9 Then
        resultat(0) = CStr(champs(0))
        resultat(1) = CStr(champs(1))
        resultat(2) = CStr(champs(2))
        resultat(3) = CStr(champs(3))
        resultat(4) = CStr(champs(4))
        resultat(5) = CStr(champs(5))
        resultat(6) = CStr(champs(6))
        resultat(7) = CStr(champs(7))
        resultat(8) = CStr(champs(8))
    ElseIf nombreChamps = 7 Then
        ' Migration de l'ancien format : Statut devient Activite,
        ' Tache devient Produit et Typologie devient TypeDossier.
        resultat(0) = CStr(champs(0))
        resultat(1) = CStr(champs(1))
        resultat(2) = CStr(champs(2))
        resultat(3) = CStr(champs(5))
        resultat(4) = CStr(champs(3))
        resultat(5) = CStr(champs(4))
        resultat(6) = vbNullString
        resultat(7) = vbNullString
        resultat(8) = CStr(champs(6))
    Else
        Err.Raise vbObjectError + 2201, "NormaliserAncienOuNouveauFormat", _
            "Format CSV non reconnu (" & nombreChamps & " colonnes)."
    End If

    NormaliserAncienOuNouveauFormat = resultat
End Function

Public Function AnalyserLigneCSV(ByVal ligne As String) As Variant
    Dim champs As Collection
    Dim tableau() As String
    Dim courant As String
    Dim dansGuillemets As Boolean
    Dim caractere As String
    Dim i As Long

    Set champs = New Collection

    i = 1
    Do While i <= Len(ligne)
        caractere = Mid$(ligne, i, 1)

        If caractere = """" Then
            If dansGuillemets And i < Len(ligne) And Mid$(ligne, i + 1, 1) = """" Then
                courant = courant & """"
                i = i + 1
            Else
                dansGuillemets = Not dansGuillemets
            End If
        ElseIf caractere = ";" And Not dansGuillemets Then
            champs.Add courant
            courant = vbNullString
        Else
            courant = courant & caractere
        End If

        i = i + 1
    Loop

    champs.Add courant
    ReDim tableau(0 To champs.Count - 1)

    For i = 1 To champs.Count
        tableau(i - 1) = CStr(champs(i))
    Next i

    AnalyserLigneCSV = tableau
End Function

Public Function ConstruireLigneCSV(ByVal champs As Variant) As String
    Dim i As Long
    Dim resultat As String

    For i = LBound(champs) To UBound(champs)
        If i > LBound(champs) Then resultat = resultat & ";"
        resultat = resultat & EncoderChampCSV(CStr(champs(i)))
    Next i

    ConstruireLigneCSV = resultat
End Function

Private Function EncoderChampCSV(ByVal valeur As String) As String
    valeur = Replace$(valeur, """", """""")
    valeur = Replace$(valeur, vbCrLf, " ")
    valeur = Replace$(valeur, vbCr, " ")
    valeur = Replace$(valeur, vbLf, " ")
    EncoderChampCSV = """" & valeur & """"
End Function

Public Function LireFichierTexte(ByVal cheminFichier As String) As String
    Dim flux As Object
    Dim charset As String

    charset = DetecterCharset(cheminFichier)
    Set flux = CreateObject("ADODB.Stream")

    With flux
        .Type = adTypeText
        .Charset = charset
        .Open
        .LoadFromFile cheminFichier
        LireFichierTexte = .ReadText(adReadAll)
        .Close
    End With
End Function

Private Function DetecterCharset(ByVal cheminFichier As String) As String
    Dim flux As Object
    Dim octets As Variant

    DetecterCharset = "windows-1252"
    Set flux = CreateObject("ADODB.Stream")

    With flux
        .Type = adTypeBinary
        .Open
        .LoadFromFile cheminFichier

        If .Size >= 3 Then
            octets = .Read(3)
            If octets(0) = &HEF And octets(1) = &HBB And octets(2) = &HBF Then
                DetecterCharset = "utf-8"
            End If
        End If

        .Close
    End With
End Function

Private Sub EcrireFichierAtomique(ByVal cheminFichier As String, ByVal contenu As String)
    Dim fso As Object
    Dim flux As Object
    Dim fichierTemp As String
    Dim fichierSauvegarde As String
    Dim cibleExistait As Boolean
    Dim numeroErreur As Long
    Dim descriptionErreur As String

    On Error GoTo GestionErreur

    Set fso = CreateObject("Scripting.FileSystemObject")
    fichierTemp = cheminFichier & ".tmp_" & Format$(Now, "yyyymmdd_hhnnss")
    fichierSauvegarde = cheminFichier & ".bak"
    cibleExistait = fso.FileExists(cheminFichier)

    Set flux = CreateObject("ADODB.Stream")
    With flux
        .Type = adTypeText
        .Charset = "utf-8"
        .Open
        .WriteText contenu
        .SaveToFile fichierTemp, adSaveCreateOverWrite
        .Close
    End With

    If fso.FileExists(fichierSauvegarde) Then fso.DeleteFile fichierSauvegarde, True
    If cibleExistait Then fso.MoveFile cheminFichier, fichierSauvegarde
    fso.MoveFile fichierTemp, cheminFichier
    If fso.FileExists(fichierSauvegarde) Then fso.DeleteFile fichierSauvegarde, True
    Exit Sub

GestionErreur:
    numeroErreur = Err.Number
    descriptionErreur = Err.Description
    On Error Resume Next
    If fso.FileExists(fichierTemp) Then fso.DeleteFile fichierTemp, True
    If Not fso.FileExists(cheminFichier) And fso.FileExists(fichierSauvegarde) Then
        fso.MoveFile fichierSauvegarde, cheminFichier
    End If
    On Error GoTo 0
    Err.Raise numeroErreur, "EcrireFichierAtomique", descriptionErreur
End Sub

Public Sub ImporterCSVVersHistorique(ByVal cheminFichier As String, ByVal wsDestination As Worksheet, _
        ByRef ligneDestination As Long, ByVal dictionnaire As Object)

    Dim contenu As String
    Dim lignes As Variant
    Dim champs As Variant
    Dim enregistrement As Variant
    Dim dateHeure As Date
    Dim cle As String
    Dim i As Long

    If Len(Dir$(cheminFichier, vbNormal)) = 0 Then Exit Sub

    contenu = LireFichierTexte(cheminFichier)
    contenu = Replace$(contenu, vbCrLf, vbLf)
    contenu = Replace$(contenu, vbCr, vbLf)
    lignes = Split(contenu, vbLf)

    For i = LBound(lignes) + 1 To UBound(lignes)
        If Len(Trim$(CStr(lignes(i)))) > 0 Then
            champs = AnalyserLigneCSV(CStr(lignes(i)))
            enregistrement = NormaliserAncienOuNouveauFormat(champs)
            cle = ConstruireCleDoublon(enregistrement(0), enregistrement(1), enregistrement(3), _
                enregistrement(4), enregistrement(5), enregistrement(6), _
                enregistrement(7), enregistrement(8))

            If Not dictionnaire.Exists(cle) Then
                dateHeure = ConvertirDateCSV(CStr(enregistrement(2)))
                dictionnaire.Add cle, True

                wsDestination.Cells(ligneDestination, "A").Value = enregistrement(0)
                wsDestination.Cells(ligneDestination, "B").Value = enregistrement(1)
                wsDestination.Cells(ligneDestination, "C").Value = dateHeure
                wsDestination.Cells(ligneDestination, "D").Value = enregistrement(3)
                wsDestination.Cells(ligneDestination, "E").Value = enregistrement(4)
                wsDestination.Cells(ligneDestination, "F").Value = enregistrement(5)
                wsDestination.Cells(ligneDestination, "G").Value = enregistrement(6)
                wsDestination.Cells(ligneDestination, "H").Value = enregistrement(7)
                wsDestination.Cells(ligneDestination, "I").Value = enregistrement(8)
                wsDestination.Cells(ligneDestination, "J").Value = DateValue(dateHeure)
                wsDestination.Cells(ligneDestination, "K").Value = _
                    DatePart("ww", dateHeure, vbMonday, vbFirstFourDays)
                wsDestination.Cells(ligneDestination, "L").Value = Format$(dateHeure, "yyyy_mm")
                wsDestination.Cells(ligneDestination, "M").Value = cle
                wsDestination.Cells(ligneDestination, "N").Value = cheminFichier
                ligneDestination = ligneDestination + 1
            End If
        End If
    Next i
End Sub
