Attribute VB_Name = "modConfiguration"
Option Explicit

Public Const FEUILLE_ACCUEIL As String = "Accueil"
Public Const FEUILLE_PARAMETRES As String = "Parametres"
Public Const FEUILLE_TEMP As String = "DATA_Temp"
Public Const FEUILLE_HISTORIQUE As String = "DATA_Historique"
Public Const FEUILLE_DASHBOARD As String = "Dashboard"

Public Const ETAT_A_ENREGISTRER As String = "A_ENREGISTRER"
Public Const CSV_HEADER As String = "NumeroDossier;PersoID;DateTime;Activite;Produit;TypeDossier;Decision;Dispo;Commentaire"

Public MonFormulaireSaisie As Object
Public ProchaineReinitialisation As Date

Public Sub AssurerStructureClasseur()
    Dim ws As Worksheet

    Set ws = ObtenirOuCreerFeuille(FEUILLE_TEMP)
    EcrireEntetesSiAbsentes ws, Array("IDTemp", "NumeroDossier", "PersoID", "DateTime", _
        "Activite", "Produit", "TypeDossier", "Decision", "Dispo", "Commentaire", _
        "Etat", "CleDoublon", "DateJour")
    ws.Columns("D").NumberFormat = "dd/mm/yyyy hh:mm:ss"
    ws.Columns("M").NumberFormat = "dd/mm/yyyy"

    Set ws = ObtenirOuCreerFeuille(FEUILLE_HISTORIQUE)
    EcrireEntetesSiAbsentes ws, Array("NumeroDossier", "PersoID", "DateTime", "Activite", _
        "Produit", "TypeDossier", "Decision", "Dispo", "Commentaire", "DateJour", _
        "SemaineISO", "Mois", "CleDoublon", "SourceCSV")
    ws.Columns("C").NumberFormat = "dd/mm/yyyy hh:mm:ss"
    ws.Columns("J").NumberFormat = "dd/mm/yyyy"

    On Error Resume Next
    ThisWorkbook.Worksheets(FEUILLE_TEMP).Visible = xlSheetVeryHidden
    ThisWorkbook.Worksheets(FEUILLE_HISTORIQUE).Visible = xlSheetVeryHidden
    On Error GoTo 0
End Sub

Private Function ObtenirOuCreerFeuille(ByVal nomFeuille As String) As Worksheet
    On Error Resume Next
    Set ObtenirOuCreerFeuille = ThisWorkbook.Worksheets(nomFeuille)
    On Error GoTo 0

    If ObtenirOuCreerFeuille Is Nothing Then
        Set ObtenirOuCreerFeuille = ThisWorkbook.Worksheets.Add( _
            After:=ThisWorkbook.Worksheets(ThisWorkbook.Worksheets.Count))
        ObtenirOuCreerFeuille.Name = nomFeuille
    End If
End Function

Private Sub EcrireEntetesSiAbsentes(ByVal ws As Worksheet, ByVal entetes As Variant)
    Dim i As Long

    If Len(Trim$(CStr(ws.Cells(1, 1).Value))) > 0 Then Exit Sub

    For i = LBound(entetes) To UBound(entetes)
        ws.Cells(1, i + 1).Value = entetes(i)
    Next i

    With ws.Rows(1)
        .Font.Bold = True
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(23, 54, 93)
    End With
End Sub

Public Function CheminBase() As String
    Dim valeur As String

    On Error Resume Next
    valeur = Trim$(CStr(ThisWorkbook.Worksheets(FEUILLE_PARAMETRES).Range("Q2").Value))
    On Error GoTo 0

    If Len(valeur) = 0 Then
        valeur = "\\Uf11pu01\EIDS_FLOA_OCTROI\BO Avenant_Courrier\DATA_Source\"
    End If

    If Right$(valeur, 1) <> "\" Then valeur = valeur & "\"
    CheminBase = valeur
End Function

Public Function CheminCSVPourDate(ByVal dateReference As Date) As String
    CheminCSVPourDate = CheminBase() & "CSV\" & Format$(dateReference, "yyyy_mm") & "\"
End Function

Public Function CheminFichierCSV(ByVal persoID As String, ByVal dateReference As Date) As String
    CheminFichierCSV = CheminCSVPourDate(dateReference) & NomFichierSecurise(persoID) & ".csv"
End Function

Public Function NomFichierSecurise(ByVal valeur As String) As String
    Dim caracteresInterdits As Variant
    Dim caractere As Variant

    caracteresInterdits = Array("\", "/", ":", "*", "?", """", "<", ">", "|")
    valeur = Trim$(valeur)

    For Each caractere In caracteresInterdits
        valeur = Replace$(valeur, CStr(caractere), "_")
    Next caractere

    If Len(valeur) = 0 Then valeur = "utilisateur"
    NomFichierSecurise = valeur
End Function

Public Sub AssurerDossier(ByVal cheminDossier As String)
    Dim fso As Object

    Set fso = CreateObject("Scripting.FileSystemObject")
    If Not fso.FolderExists(cheminDossier) Then fso.CreateFolder cheminDossier
End Sub

Public Function NormaliserTexte(ByVal valeur As Variant) As String
    Dim texte As String

    texte = LCase$(Trim$(CStr(valeur)))
    texte = Replace$(texte, vbCr, " ")
    texte = Replace$(texte, vbLf, " ")
    texte = Replace$(texte, vbTab, " ")

    Do While InStr(texte, "  ") > 0
        texte = Replace$(texte, "  ", " ")
    Loop

    NormaliserTexte = texte
End Function

Public Function ConstruireCleDoublon(ByVal numeroDossier As Variant, ByVal persoID As Variant, _
        ByVal activite As Variant, ByVal produit As Variant, ByVal typeDossier As Variant, _
        ByVal decision As Variant, ByVal dispo As Variant, ByVal commentaire As Variant) As String

    ConstruireCleDoublon = NormaliserTexte(numeroDossier) & Chr$(30) & _
        NormaliserTexte(persoID) & Chr$(30) & _
        NormaliserTexte(activite) & Chr$(30) & _
        NormaliserTexte(produit) & Chr$(30) & _
        NormaliserTexte(typeDossier) & Chr$(30) & _
        NormaliserTexte(decision) & Chr$(30) & _
        NormaliserTexte(dispo) & Chr$(30) & _
        NormaliserTexte(commentaire)
End Function

Public Function ConvertirDateCSV(ByVal texte As String) As Date
    texte = Trim$(texte)

    If Len(texte) >= 10 And Mid$(texte, 5, 1) = "-" And Mid$(texte, 8, 1) = "-" Then
        ConvertirDateCSV = DateSerial(CLng(Left$(texte, 4)), CLng(Mid$(texte, 6, 2)), _
            CLng(Mid$(texte, 9, 2)))

        If Len(texte) >= 19 Then
            ConvertirDateCSV = ConvertirDateCSV + TimeSerial(CLng(Mid$(texte, 12, 2)), _
                CLng(Mid$(texte, 15, 2)), CLng(Mid$(texte, 18, 2)))
        End If
    ElseIf Len(texte) >= 10 And Mid$(texte, 3, 1) = "/" And Mid$(texte, 6, 1) = "/" Then
        ConvertirDateCSV = DateSerial(CLng(Mid$(texte, 7, 4)), CLng(Mid$(texte, 4, 2)), _
            CLng(Left$(texte, 2)))

        If Len(texte) >= 19 Then
            ConvertirDateCSV = ConvertirDateCSV + TimeSerial(CLng(Mid$(texte, 12, 2)), _
                CLng(Mid$(texte, 15, 2)), CLng(Mid$(texte, 18, 2)))
        End If
    ElseIf IsDate(texte) Then
        ConvertirDateCSV = CDate(texte)
    Else
        Err.Raise vbObjectError + 2100, "ConvertirDateCSV", "Date CSV invalide : " & texte
    End If
End Function

Public Function IdentifiantTemporaire() As String
    Randomize
    IdentifiantTemporaire = Format$(Now, "yyyymmddhhnnss") & "-" & _
        Format$(CLng(Timer * 1000), "00000000") & "-" & Format$(CLng(Rnd() * 999999), "000000")
End Function

Public Sub SauvegarderClasseurSiPossible()
    On Error Resume Next
    If Len(ThisWorkbook.Path) > 0 And Not ThisWorkbook.ReadOnly Then ThisWorkbook.Save
    On Error GoTo 0
End Sub
